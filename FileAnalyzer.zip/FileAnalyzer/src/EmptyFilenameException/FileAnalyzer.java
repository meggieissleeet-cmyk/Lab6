package EmptyFilenameException;
import java.io.*;
import java.util.Scanner;

public class FileAnalyzer {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            // Prompt user
            System.out.print("Enter the file path (example: C:/Users/meg/Desktop/sample.txt): ");
            String filename = input.nextLine();


            // Check for empty filename
            if (filename.trim().isEmpty()) {
                throw new EmptyFilenameException("Filename cannot be empty.");
            }

            File file = new File(filename);

            // Check if file exists
            if (!file.exists()) {
                throw new FileNotFoundException("File not found: " + filename);
            }

            // Counters
            int lineCount = 0;
            int wordCount = 0;
            int charCount = 0;

            // Read file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {
                lineCount++;

                // Count characters (including spaces)
                charCount += line.length();

                // Count words
                if (!line.trim().isEmpty()) {
                    String[] words = line.trim().split("\s+");
                    wordCount += words.length;
                }
            }

            reader.close();

            // Display results
            System.out.println("\n--- File Analysis ---");
            System.out.println("Lines: " + lineCount);
            System.out.println("Words: " + wordCount);
            System.out.println("Characters: " + charCount);

            // Write to output file
            PrintWriter writer = new PrintWriter("analysis_output.txt");

            writer.println("File Analysis Results:");
            writer.println("Lines: " + lineCount);
            writer.println("Words: " + wordCount);
            writer.println("Characters: " + charCount);

            writer.close();

            System.out.println("\nResults written to analysis_output.txt");

        } catch (EmptyFilenameException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (IOException e) {
            System.out.println("Error reading file.");

        } finally {
            input.close();
        }
    }
}